package com.example.chaitanya.mychat.UploadResume;

/**
 * Created by Chaitanya on 03-04-2018.
 */

public class ConstantResume {
    public static final String STORAGE_PATH_UPLOADS = "uploads";
    public static final String DATABASE_PATH_UPLOADS = "uploads";
}
